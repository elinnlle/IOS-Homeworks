//
//  WishMakerViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 29.10.2024.
//

import UIKit

extension UIColor {
    static let customTitleColor = UIColor.black
    static let customDescriptionColor = UIColor.white
    static let lightPurple = UIColor(red: 0.8, green: 0.7, blue: 2.0, alpha: 1.0) // Цвет фона
}

final class WishMakerViewController: UIViewController {
    // MARK: - Constants
    enum Constants {
        static let sliderMin: Double = 0
        static let sliderMax: Double = 1
        static let red: String = "Red"
        static let green: String = "Green"
        static let blue: String = "Blue"
        static let stackRadius: CGFloat = 20
        static let stackBottom: CGFloat = -40
        static let stackLeading: CGFloat = 20
        static let titleFontSize: CGFloat = 32
        static let descriptionFontSize: CGFloat = 18
        static let titleTopOffset: CGFloat = 30
        static let descriptionTopOffset: CGFloat = 80
        static let descriptionLeadingTrailingOffset: CGFloat = 20
        static let stackSpacing: CGFloat = 10
        static let buttonFontSize: CGFloat = 18
        static let buttonTopOffset: CGFloat = -2
    }

    // MARK: - Properties
    private var sliderRedValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var sliderGreenValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var sliderBlueValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var slidersStackView: UIStackView! // Ссылка на стек слайдеров

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    // MARK: - UI Configuration
    private func configureUI() {
        view.backgroundColor = .lightPurple
        
        configureTitle()
        configureDescription()
        configureSliders()
        configureToggleButton()
    }
    
    // Работа с заголовком
    private func configureTitle() {
        let title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "WishMaker"
        title.font = UIFont.boldSystemFont(ofSize: Constants.titleFontSize) // Жирный шрифт
        title.textColor = .customTitleColor
        title.textAlignment = .center
        
        view.addSubview(title)
        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            title.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.descriptionLeadingTrailingOffset),
            title.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.titleTopOffset)
        ])
    }
    
    // Работа с описанием
    private func configureDescription() {
        let description = UILabel()
        description.translatesAutoresizingMaskIntoConstraints = false
        description.text = "Мы не знаем, что это такое, если бы мы знали, что это такое, но мы не знаем, что это такое🫠"
        description.font = UIFont.systemFont(ofSize: Constants.descriptionFontSize)
        description.textColor = .customDescriptionColor
        description.numberOfLines = 0
        description.lineBreakMode = .byWordWrapping // Перенос текста по словам
        description.textAlignment = .center

        view.addSubview(description)
        NSLayoutConstraint.activate([
            description.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            description.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.descriptionLeadingTrailingOffset),
            description.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.descriptionTopOffset), // На 20 пунктов ниже заголовка
            description.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -Constants.descriptionLeadingTrailingOffset) // Ограничение справа
        ])
    }
    
    // Работа со слайдерами
    private func configureSliders() {
        slidersStackView = UIStackView()
        slidersStackView.translatesAutoresizingMaskIntoConstraints = false
        slidersStackView.axis = .vertical
        slidersStackView.spacing = Constants.stackSpacing // Добавление промежутков между слайдерами
        view.addSubview(slidersStackView)
        slidersStackView.layer.cornerRadius = Constants.stackRadius
        slidersStackView.clipsToBounds = true
        
        let sliderRed = CustomSlider(title: Constants.red, min : Constants.sliderMin, max: Constants.sliderMax)
        let sliderGreen = CustomSlider(title: Constants.green, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderBlue = CustomSlider(title: Constants.blue, min: Constants.sliderMin, max: Constants.sliderMax)
        
        // Установка обработчиков для изменения значений слайдеров
        sliderRed.valueChanged = { [weak self] value in
            self?.sliderRedValue = value
        }
        
        sliderGreen.valueChanged = { [weak self] value in
            self?.sliderGreenValue = value
        }
        
        sliderBlue.valueChanged = { [weak self] value in
            self?.sliderBlueValue = value
        }
        
        for slider in [sliderRed, sliderGreen, sliderBlue] {
            slidersStackView.addArrangedSubview(slider)
        }
        
        NSLayoutConstraint.activate([
            slidersStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            slidersStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.stackLeading),
            slidersStackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: Constants.stackBottom)
        ])
    }
    
    // Кнопка скрытия-показа слайдеров
    private func configureToggleButton() {
        let toggleButton = UIButton(type: .system)
        toggleButton.translatesAutoresizingMaskIntoConstraints = false
        toggleButton.setTitle("Убрать/показать слайдеры", for: .normal)
        toggleButton.setTitleColor(.black, for: .normal) // Черный цвет текста кнопки
        toggleButton.titleLabel?.font = UIFont.systemFont(ofSize: Constants.buttonFontSize) // Размер шрифта кнопки
        toggleButton.addTarget(self, action: #selector(toggleSliders), for: .touchUpInside)
        
        view.addSubview(toggleButton)
        NSLayoutConstraint.activate([
            toggleButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toggleButton.bottomAnchor.constraint(equalTo: slidersStackView.topAnchor, constant: Constants.buttonTopOffset)
        ])
    }
    
    @objc private func toggleSliders() {
        slidersStackView.isHidden.toggle()
    }
    
    // MARK: - Background Color Update
    private func updateBackgroundColor() {
        let red = CGFloat(sliderRedValue)
        let green = CGFloat(sliderGreenValue)
        let blue = CGFloat(sliderBlueValue)
        view.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
}
