//
//  WishStoringViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 05.11.2024.
//

import UIKit

final class WishStoringViewController: UIViewController {
    
    // MARK: - Properties
    private let table: UITableView = UITableView(frame: .zero)
    private let defaults = UserDefaults.standard
    
    // MARK: - Constants
    private struct Constants {
        static let tableCornerRadius: CGFloat = 10
        static let tableOffset: CGFloat = 5
        static let numberOfSections = 2
        static let wishesKey = "wishesKey"
    }
    
    // Массив желаний
    private var wishArray: [String] = []

    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        loadWishes() // Загружаем желания из UserDefaults
        configureTable()
    }
    
    // MARK: - Data Management
    private func loadWishes() {
        if let savedWishes = defaults.array(forKey: Constants.wishesKey) as? [String] {
            wishArray = savedWishes
        }
    }

    private func saveWishes() {
        defaults.set(wishArray, forKey: Constants.wishesKey)
    }

    // MARK: - UI Configuration
    private func configureTable() {
        view.addSubview(table)
        table.backgroundColor = .lightPurple
        table.dataSource = self
        table.delegate = self // Делегат для обработки действий
        table.separatorStyle = .none
        table.layer.cornerRadius = Constants.tableCornerRadius
        
        // Регистрация пользовательских ячеек
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
        table.register(AddWishCell.self, forCellReuseIdentifier: AddWishCell.reuseId)

        table.pin(to: view, Constants.tableOffset)
    }
}

// MARK: - UITableViewDataSource
extension WishStoringViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return Constants.numberOfSections // Возвращаем количество секций
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return wishArray.count
        case 1:
            return 1
        default:
            return 0
        }
    }
    
    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        if indexPath.section == 0 {
            // Создаем ячейку WrittenWishCell для первой секции
            let cell = tableView.dequeueReusableCell(withIdentifier: WrittenWishCell.reuseId, for: indexPath)

            guard let wishCell = cell as? WrittenWishCell else { return cell }

            wishCell.configure(with: wishArray[indexPath.row]) // Настройка ячейки с желанием
            
            // Добавляем обработчик нажатия на ячейку для редактирования
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleEditWish(_:)))
            wishCell.addGestureRecognizer(tapGesture)
            wishCell.tag = indexPath.row // Сохраняем индекс желания
            
            return wishCell
        } else if indexPath.section == 1 {
            // Создаем ячейку AddWishCell для второй секции
            let cell = tableView.dequeueReusableCell(withIdentifier: AddWishCell.reuseId, for: indexPath) as! AddWishCell
            
            // Настройки для добавления желания
            cell.addWish = { [weak self] wish in
                self?.wishArray.append(wish) // Добавляем желание в массив
                self?.saveWishes() // Сохраняем обновленный массив в UserDefaults
                self?.table.reloadData() // Обновляем таблицу
            }
            
            return cell
        }
        
        // Возвращаем пустую ячейку
        return UITableViewCell()
    }
}

// MARK: - UITableViewDelegate
extension WishStoringViewController: UITableViewDelegate {
    func tableView(
        _ tableView: UITableView,
        commit editingStyle: UITableViewCell.EditingStyle,
        forRowAt indexPath: IndexPath
    ) {
        if editingStyle == .delete {
            // Удаляем желание из массива
            let wishToDelete = wishArray[indexPath.row]
            let alert = UIAlertController(
                title: "Удалить желание",
                message: "Вы уверены, что хотите удалить '\(wishToDelete)'?",
                preferredStyle: .alert
            )
            alert.addAction(
                UIAlertAction(
                    title: "Удалить",
                    style: .destructive
                ) { [weak self] _ in
                    self?.wishArray.remove(at: indexPath.row)
                    self?.saveWishes()
                    tableView.deleteRows(at: [indexPath], with: .fade) // Удаляем строку из таблицы
                }
            )
            alert.addAction(UIAlertAction(title: "Отмена", style: .cancel))
            present(alert, animated: true)
        }
    }
    
    // MARK: - Edit Wish Handling
    @objc private func handleEditWish(_ sender: UITapGestureRecognizer) {
        guard let cell = sender.view as? WrittenWishCell else { return }
        let index = cell.tag // Получаем индекс желания из тега ячейки
        let currentWish = wishArray[index]
        
        let alert = UIAlertController(
            title: "Редактирование желания",
            message: "Измените текст",
            preferredStyle: .alert
        )
        alert.addTextField { textField in
            textField.text = currentWish
        }
        
        alert.addAction(
            UIAlertAction(
                title: "Сохранить",
                style: .default
            ) { [weak self] _ in
                if let newWish = alert.textFields?.first?.text,
                   !newWish.isEmpty {
                self?.wishArray[index] = newWish // Обновляем желание в массиве
                self?.saveWishes() // Сохраняем обновленный массив в UserDefaults
                self?.table.reloadData() // Обновляем таблицу
            }
        })
        
        alert.addAction(
            UIAlertAction(
                title: "Выйти",
                style: .cancel
            )
        )
        present(alert, animated: true)
    }
}
