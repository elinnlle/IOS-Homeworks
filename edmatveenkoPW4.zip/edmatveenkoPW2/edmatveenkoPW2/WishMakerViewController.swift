//
//  WishMakerViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 29.10.2024.
//

import UIKit

extension UIColor {
    static let customTitleColor = UIColor.black
    static let customDescriptionColor = UIColor.white
    static let lightPurple = UIColor(red: 0.8, green: 0.7, blue: 2.0, alpha: 1.0) // Цвет фона
}

final class WishMakerViewController: UIViewController {
    // MARK: - Constants
    enum Constants {
        static let sliderMin: Double = 0
        static let sliderMax: Double = 1
        static let red: String = "Red"
        static let green: String = "Green"
        static let blue: String = "Blue"
        static let stackRadius: CGFloat = 20
        static let stackBottom: CGFloat = -170
        static let stackLeading: CGFloat = 20
        static let titleFontSize: CGFloat = 32
        static let descriptionFontSize: CGFloat = 18
        static let titleTopOffset: CGFloat = 30
        static let descriptionTopOffset: CGFloat = 80
        static let descriptionLeadingTrailingOffset: CGFloat = 20
        static let stackSpacing: CGFloat = 10
        static let buttonFontSize: CGFloat = 18
        static let buttonTopOffset: CGFloat = -2
        static let buttonHeight: CGFloat = 50
        static let buttonBottom: CGFloat = 110
        static let scheduleButtonBottom: CGFloat = 50
        static let buttonSide: CGFloat = 20
        static let buttonText: String = "Мои желания"
        static let scheduleButtonText: String = "Запланировать желания"
        static let buttonRadius: CGFloat = 20
    }

    // MARK: - Properties
    private let addWishButton: UIButton = UIButton(type: .system)
    private let scheduleWishesButton: UIButton = UIButton(type: .system) // Новая кнопка
    
    private var sliderRedValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var sliderGreenValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var sliderBlueValue: Double = 0 {
        didSet {
            updateBackgroundColor()
        }
    }
    
    private var slidersStackView: UIStackView! // Ссылка на стек слайдеров

    private var currentColor: UIColor = .lightPurple {
        didSet {
            updateButtonTitleColors()
        }
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    // MARK: - UI Configuration
    private func configureUI() {
        view.backgroundColor = .lightPurple
        
        configureTitle()
        configureDescription()
        configureSliders()
        configureToggleButton()
        configureActionStack() // Изменено на вызов новой функции
    }
    
    // Работа с заголовком
    private func configureTitle() {
        let title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "WishMaker"
        title.font = UIFont.boldSystemFont(ofSize: Constants.titleFontSize) // Жирный шрифт
        title.textColor = .customTitleColor
        title.textAlignment = .center
        
        view.addSubview(title)
        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            title.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.descriptionLeadingTrailingOffset),
            title.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.titleTopOffset)
        ])
    }
    
    // Работа с описанием
    private func configureDescription() {
        let description = UILabel()
        description.translatesAutoresizingMaskIntoConstraints = false
        description.text = "Мы не знаем, что это такое, если бы мы знали, что это такое, но мы не знаем, что это такое🫠"
        description.font = UIFont.systemFont(ofSize: Constants.descriptionFontSize)
        description.textColor = .customDescriptionColor
        description.numberOfLines = 0
        description.lineBreakMode = .byWordWrapping // Перенос текста по словам
        description.textAlignment = .center

        view.addSubview(description)
        NSLayoutConstraint.activate([
            description.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            description.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.descriptionLeadingTrailingOffset),
            description.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.descriptionTopOffset),
            description.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -Constants.descriptionLeadingTrailingOffset) // Ограничение справа
        ])
    }
    
    // Работа со слайдерами
    private func configureSliders() {
        slidersStackView = UIStackView()
        slidersStackView.translatesAutoresizingMaskIntoConstraints = false
        slidersStackView.axis = .vertical
        slidersStackView.spacing = Constants.stackSpacing // Добавление промежутков между слайдерами
        view.addSubview(slidersStackView)
        
        // Установка фона и скругления углов для стека слайдеров
        slidersStackView.backgroundColor = .white
        slidersStackView.layer.cornerRadius = Constants.stackRadius
        slidersStackView.clipsToBounds = true

        let sliderRed = CustomSlider(title: Constants.red, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderGreen = CustomSlider(title: Constants.green, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderBlue = CustomSlider(title: Constants.blue, min: Constants.sliderMin, max: Constants.sliderMax)
        
        // Установка обработчиков для изменения значений слайдеров
        sliderRed.valueChanged = { [weak self] value in
            self?.sliderRedValue = value
        }
        
        sliderGreen.valueChanged = { [weak self] value in
            self?.sliderGreenValue = value
        }
        
        sliderBlue.valueChanged = { [weak self] value in
            self?.sliderBlueValue = value
        }
        
        for slider in [sliderRed, sliderGreen, sliderBlue] {
            slidersStackView.addArrangedSubview(slider)
        }
        
        NSLayoutConstraint.activate([
            slidersStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            slidersStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.stackLeading),
            slidersStackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: Constants.stackBottom)
        ])
    }
    
    // Кнопка скрытия-показа слайдеров
    private func configureToggleButton() {
        let toggleButton = UIButton(type: .system)
        toggleButton.translatesAutoresizingMaskIntoConstraints = false
        toggleButton.setTitle("Убрать/показать слайдеры", for: .normal)
        toggleButton.setTitleColor(.black, for: .normal) // Черный цвет текста кнопки
        toggleButton.titleLabel?.font = UIFont.systemFont(ofSize: Constants.buttonFontSize) // Размер шрифта кнопки
        toggleButton.addTarget(self, action: #selector(toggleSliders), for: .touchUpInside)
        
        view.addSubview(toggleButton)
        NSLayoutConstraint.activate([
            toggleButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toggleButton.bottomAnchor.constraint(equalTo: slidersStackView.topAnchor, constant: Constants.buttonTopOffset)
        ])
    }
    
    // Группировка кнопок
    private func configureActionStack() {
        let actionStack = UIStackView()
        actionStack.translatesAutoresizingMaskIntoConstraints = false
        actionStack.axis = .vertical
        actionStack.spacing = Constants.stackSpacing
        
        view.addSubview(actionStack)
        
        // Настройка кнопок
        configureAddWishButton()
        configureScheduleWishesButton() // Настройка новой кнопки
        
        // Добавление кнопок в стек
        for button in [addWishButton, scheduleWishesButton] {
            actionStack.addArrangedSubview(button)
        }
        
        actionStack.pinBottom(to: view, Constants.stackBottom)
        actionStack.pinHorizontal(to: view, Constants.stackLeading)
    }
    
    // Кнопка 'Мои желания'
    private func configureAddWishButton() {
        view.addSubview(addWishButton)
        addWishButton.setHeight(Constants.buttonHeight)
        addWishButton.pinBottom(to: view, Constants.buttonBottom)
        addWishButton.pinHorizontal(to: view, Constants.buttonSide)
            
        addWishButton.backgroundColor = .white
        addWishButton.setTitleColor(.black, for: .normal)
        addWishButton.setTitle(Constants.buttonText, for: .normal)
            
        addWishButton.layer.cornerRadius = Constants.buttonRadius
        addWishButton.addTarget(self, action: #selector(addWishButtonPressed), for: .touchUpInside)
    }
    
    // Кнопка 'Запланировать желания'
    private func configureScheduleWishesButton() {
        view.addSubview(scheduleWishesButton)
        scheduleWishesButton.setHeight(Constants.buttonHeight)
        scheduleWishesButton.pinBottom(to: view, Constants.scheduleButtonBottom)
        scheduleWishesButton.pinHorizontal(to: view, Constants.buttonSide)
            
        scheduleWishesButton.backgroundColor = .white
        scheduleWishesButton.setTitleColor(.black, for: .normal)
        scheduleWishesButton.setTitle(Constants.scheduleButtonText, for: .normal)
            
        scheduleWishesButton.layer.cornerRadius = Constants.buttonRadius
        scheduleWishesButton.addTarget(self, action: #selector(scheduleWishesButtonPressed), for: .touchUpInside)
    }
    
    @objc private func toggleSliders() {
        slidersStackView.isHidden.toggle()
    }
    
    // Обработчик нажатия на кнопку 'Мои желания'
    @objc private func addWishButtonPressed() {
        present(WishStoringViewController(), animated: true)
    }
    
    // Обработчик нажатия на кнопку 'Запланировать желания'
    @objc private func scheduleWishesButtonPressed() {
        let vc = WishCalendarViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    // MARK: - Background Color Update
    private func updateBackgroundColor() {
        let red = CGFloat(sliderRedValue)
        let green = CGFloat(sliderGreenValue)
        let blue = CGFloat(sliderBlueValue)
        currentColor = UIColor(red: red, green: green, blue: blue, alpha: 1.0)
        view.backgroundColor = currentColor
    }

    private func updateButtonTitleColors() {
        let titleColor = currentColor
        addWishButton.setTitleColor(titleColor, for: .normal)
        scheduleWishesButton.setTitleColor(titleColor, for: .normal)
    }
}
