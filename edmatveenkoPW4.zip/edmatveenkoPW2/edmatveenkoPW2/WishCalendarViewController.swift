//
//  WishCalendarViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 02.12.2024.
//

import UIKit

// Модель события
struct WishEventModel: Codable {
    let title: String
    let description: String
    let startDate: String
    let endDate: String
}

final class WishCalendarViewController: UIViewController, WishEventCreationDelegate {

    // MARK: - Constants
    private enum Constants {
        static let cellIdentifier = WishEventCell.reuseIdentifier
        static let cellHeight: CGFloat = 100
        static let collectionTop: CGFloat = 10
        static let collectionBottom: CGFloat = 10
        static let collectionHorizontalInset: CGFloat = 10
        static let contentInset: UIEdgeInsets = UIEdgeInsets(
            top: collectionTop,
            left: 0,
            bottom: collectionBottom,
            right: 0
        )
    }

    // MARK: - UI Elements
    private let collectionView: UICollectionView = UICollectionView(
        frame: .zero,
        collectionViewLayout: UICollectionViewFlowLayout()
    )
    
    // Хранилище событий
    private var events: [WishEventModel] = []

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        configureCollection()
        setupNavigationBar()
        loadEvents() // Загружаем события из UserDefaults
    }

    // MARK: - Настройка навигационной панели
    private func setupNavigationBar() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addEvent)
        )
    }
    
    // MARK: - Действие добавления события
    @objc private func addEvent() {
        let eventCreationVC = WishEventCreationView()
        eventCreationVC.delegate = self // Устанавливаем делегата
        let navigationController = UINavigationController(rootViewController: eventCreationVC)
        present(navigationController, animated: true, completion: nil)
    }
    
    // MARK: - Делегат для создания события
    func didCreateEvent(_ event: WishEventModel) {
        events.append(event) // Добавляем новое событие в массив
        saveEvents() // Сохраняем события в UserDefaults
        saveWishToUserDefaults(event.title) // Добавляем название желания в UserDefaults
        collectionView.reloadData() // Перезагружаем коллекцию
    }
    
    // Сохраняем названия желаний в UserDefaults для использования в WishStoringViewController
    private func saveWishToUserDefaults(_ wish: String) {
        let defaults = UserDefaults.standard
        var currentWishes = defaults.array(forKey: "wishesKey") as? [String] ?? []
        if !currentWishes.contains(wish) {
            currentWishes.append(wish)
            defaults.set(currentWishes, forKey: "wishesKey")
        }
    }

    // MARK: - Сохранение и загрузка событий
    private func saveEvents() {
        if let encoded = try? JSONEncoder().encode(events) {
            UserDefaults.standard.set(encoded, forKey: "events")
        }
    }

    private func loadEvents() {
        if let data = UserDefaults.standard.data(forKey: "events"),
           let decodedEvents = try? JSONDecoder().decode([WishEventModel].self, from: data) {
            events = decodedEvents
            collectionView.reloadData() // Перезагружаем коллекцию после загрузки
        }
    }

    // MARK: - Настройка коллекции
    private func configureCollection() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        collectionView.alwaysBounceVertical = true // Включаем вертикальную прокрутку
        collectionView.showsVerticalScrollIndicator = false // Скрываем индикатор прокрутки
        collectionView.contentInset = Constants.contentInset // Устанавливаем отступы
        collectionView.register(WishEventCell.self, forCellWithReuseIdentifier: Constants.cellIdentifier)
        view.addSubview(collectionView)
        collectionView.pinHorizontal(to: view)
        collectionView.pinBottom(to: view.safeAreaLayoutGuide.bottomAnchor)
        collectionView.pinTop(to: view.safeAreaLayoutGuide.topAnchor, Constants.collectionTop)
    }
}

// MARK: - UICollectionViewDataSource
extension WishCalendarViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return events.count // Количество событий
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: Constants.cellIdentifier, for: indexPath
        )
        guard let wishEventCell = cell as? WishEventCell else { return cell }
        let event = events[indexPath.item] // Получаем событие
        wishEventCell.configure(with: event) // Конфигурируем ячейку
        return wishEventCell
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension WishCalendarViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(
        _ collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAt indexPath: IndexPath
    ) -> CGSize {
        return CGSize(width: collectionView.bounds.width - Constants.collectionHorizontalInset, height: Constants.cellHeight)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedEvent = events[indexPath.item]
        let detailVC = WishEventDetailViewController()
        detailVC.event = selectedEvent
        detailVC.onUpdate = { [weak self] updatedEvent in
            self?.events[indexPath.item] = updatedEvent
            self?.saveEvents()
            self?.collectionView.reloadData()
        }
        detailVC.onDelete = { [weak self] in
            self?.events.remove(at: indexPath.item)
            self?.saveEvents()
            self?.collectionView.reloadData()
        }
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
