//
//  WishStoringViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 05.12.2024.
//

import UIKit

class WishEventCell: UICollectionViewCell {
    
    // MARK: - Свойства
    static let reuseIdentifier: String = "WishEventCell"
    
    private let wrapView: UIView = UIView() // Обертка для ячейки
    private let titleLabel: UILabel = UILabel() // Заголовок события
    private let descriptionLabel: UILabel = UILabel() // Описание события
    private let startDateLabel: UILabel = UILabel() // Метка для даты начала
    private let endDateLabel: UILabel = UILabel() // Метка для даты окончания
    
    // MARK: - Constants
    private struct Constants {
        static let offset: CGFloat = 8.0
        static let cornerRadius: CGFloat = 10.0
        static let backgroundColor: UIColor = .white
        static let titleFont: UIFont = .boldSystemFont(ofSize: 16)
        static let descriptionFont: UIFont = .systemFont(ofSize: 14)
        static let dateFont: UIFont = .systemFont(ofSize: 12)
        static let titleTop: CGFloat = 12.0
        static let titleLeading: CGFloat = 12.0
        static let descriptionTop: CGFloat = 4.0
        static let descriptionLeading: CGFloat = 12.0
        static let dateTop: CGFloat = 8.0
        static let dateLeading: CGFloat = 12.0
        static let endDateTop: CGFloat = 4.0 // Отступ для даты окончания
    }
    
    // MARK: - Lifecycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        configureWrap() // Настройка обертки
        configureTitleLabel() // Настройка заголовка
        configureDescriptionLabel() // Настройка описания
        configureStartDateLabel() // Настройка даты начала
        configureEndDateLabel() // Настройка даты окончания
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Cell Configuration
    func configure(with event: WishEventModel) {
        titleLabel.text = event.title // Установка заголовка
        descriptionLabel.text = event.description // Установка описания
        startDateLabel.text = "Дата начала: \(event.startDate)" // Установка даты начала
        endDateLabel.text = "Дата окончания: \(event.endDate)" // Установка даты окончания
    }
    
    // MARK: - Настройка интерфейса
    private func configureWrap() {
        addSubview(wrapView)
        wrapView.pin(to: self, Constants.offset)
        wrapView.layer.cornerRadius = Constants.cornerRadius
        wrapView.backgroundColor = Constants.backgroundColor
    }
    
    private func configureTitleLabel() {
        wrapView.addSubview(titleLabel)
        titleLabel.textColor = .black
        titleLabel.pinTop(to: wrapView, Constants.titleTop)
        titleLabel.font = Constants.titleFont
        titleLabel.pinLeft(to: wrapView, Constants.titleLeading)
    }
    
    private func configureDescriptionLabel() {
        wrapView.addSubview(descriptionLabel)
        descriptionLabel.textColor = .darkGray
        descriptionLabel.pinTop(to: titleLabel.bottomAnchor, Constants.descriptionTop)
        descriptionLabel.font = Constants.descriptionFont
        descriptionLabel.pinLeft(to: wrapView, Constants.descriptionLeading)
    }
    
    private func configureStartDateLabel() {
        wrapView.addSubview(startDateLabel)
        startDateLabel.textColor = .lightGray
        startDateLabel.pinTop(to: descriptionLabel.bottomAnchor, Constants.dateTop)
        startDateLabel.font = Constants.dateFont
        startDateLabel.pinLeft(to: wrapView, Constants.dateLeading)
    }
    
    private func configureEndDateLabel() {
        wrapView.addSubview(endDateLabel)
        endDateLabel.textColor = .lightGray
        endDateLabel.pinTop(to: startDateLabel.bottomAnchor, Constants.endDateTop)
        endDateLabel.font = Constants.dateFont
        endDateLabel.pinLeft(to: wrapView, Constants.dateLeading)
    }
}
