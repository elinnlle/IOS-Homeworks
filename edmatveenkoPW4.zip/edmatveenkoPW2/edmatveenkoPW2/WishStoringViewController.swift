//
//  WishStoringViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 05.11.2024.
//

import UIKit

final class WishStoringViewController: UIViewController {
    
    // MARK: - UI Elements
    private let table: UITableView = UITableView(frame: .zero)
    private let defaults = UserDefaults.standard
    
    // MARK: - Constants
    private struct Constants {
        static let tableCornerRadius: CGFloat = 10
        static let tableOffset: CGFloat = 5
        static let numberOfSections = 2
        static let wishesKey = "wishesKey"
    }
    
    // Массив для хранения желаний
    private var wishArray: [String] = []

    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        loadWishes() // Загружаем желания из UserDefaults
        configureTable()
    }
    
    // MARK: - Data Management
    private func loadWishes() {
        if let savedWishes = defaults.array(forKey: Constants.wishesKey) as? [String] {
            wishArray = Array(Set(savedWishes)) // Убираем дубликаты
        }
    }

    private func saveWishes() {
        defaults.set(wishArray, forKey: Constants.wishesKey) // Сохраняем желания
    }

    // MARK: - UI Configuration
    private func configureTable() {
        view.addSubview(table)
        table.backgroundColor = .lightPurple
        table.dataSource = self
        table.delegate = self
        table.separatorStyle = .none
        table.layer.cornerRadius = Constants.tableCornerRadius
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
        table.register(AddWishCell.self, forCellReuseIdentifier: AddWishCell.reuseId)
        table.pin(to: view, Constants.tableOffset)
    }
}

// MARK: - UITableViewDataSource
extension WishStoringViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return Constants.numberOfSections
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return wishArray.count // Количество сохранённых желаний
        case 1:
            return 1 // Ячейка для добавления нового желания
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: WrittenWishCell.reuseId, for: indexPath)
            guard let wishCell = cell as? WrittenWishCell else { return cell }
            wishCell.configure(with: wishArray[indexPath.row]) // Настраиваем ячейку желания
            return wishCell
        } else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: AddWishCell.reuseId, for: indexPath) as! AddWishCell
            cell.addWish = { [weak self] wish in
                self?.wishArray.append(wish)
                self?.saveWishes() // Сохраняем изменения
                self?.table.reloadData() // Обновляем таблицу
            }
            return cell
        }
        return UITableViewCell()
    }
}

// MARK: - UITableViewDelegate
extension WishStoringViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            wishArray.remove(at: indexPath.row) // Удаляем желание
            saveWishes()
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
