//
//  WishEventDetailViewController.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 05.12.2024.
//

import UIKit

final class WishEventDetailViewController: UIViewController {
    
    // MARK: - UI Elements
    private let titleTextField = UITextField()
    private let descriptionTextField = UITextField()
    private let startDateTextField = UITextField()
    private let endDateTextField = UITextField()
    private let saveButton = UIButton(type: .system)
    private let deleteButton = UIButton(type: .system)
    
    var event: WishEventModel?
    var onDelete: (() -> Void)?
    var onUpdate: ((WishEventModel) -> Void)?
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        populateFields()
    }
    
    // MARK: - Настройка пользовательского интерфейса
    private func setupUI() {
        titleTextField.placeholder = "Название желания"
        descriptionTextField.placeholder = "Описание желания"
        startDateTextField.placeholder = "Дата начала"
        endDateTextField.placeholder = "Дата окончания"
        
        let stackView = UIStackView(
            arrangedSubviews: [
                titleTextField,
                descriptionTextField,
                startDateTextField,
                endDateTextField,
                saveButton,
                deleteButton
            ]
        )
        stackView.axis = .vertical
        stackView.spacing = 16.0
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stackView)
        
        stackView.pinCenter(to: view)
        stackView.pinLeft(to: view, 20)
        stackView.pinRight(to: view, 20)
        
        saveButton.setTitle("Сохранить изменения", for: .normal)
        saveButton.addTarget(self, action: #selector(saveEvent), for: .touchUpInside)
        
        deleteButton.setTitle("Удалить желание", for: .normal)
        deleteButton.addTarget(self, action: #selector(deleteEvent), for: .touchUpInside)
    }
    
    private func populateFields() {
        guard let event = event else { return }
        titleTextField.text = event.title
        descriptionTextField.text = event.description
        startDateTextField.text = event.startDate
        endDateTextField.text = event.endDate
    }
    
    // MARK: - Действия
    @objc private func saveEvent() {
        guard let title = titleTextField.text, !title.isEmpty else {
            showAlert(message: "Нельзя сохранять желание без названия😕")
            return
        }
        
        let updatedEvent = WishEventModel(
            title: title,
            description: descriptionTextField.text ?? "",
            startDate: startDateTextField.text ?? "",
            endDate: endDateTextField.text ?? ""
        )
        
        onUpdate?(updatedEvent)
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func deleteEvent() {
        let alert = UIAlertController(title: "Подтверждение удаления", message: "Вы уверены, что хотите удалить это желание?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Отмена", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Удалить", style: .destructive, handler: { [weak self] _ in
            self?.onDelete?() // Вызываем обработчик удаления
            self?.navigationController?.popViewController(animated: true) // Возвращаемся к списку желаний
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
