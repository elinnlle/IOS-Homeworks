//
//  WishEventCreationView.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 04.12.2024.
//

import UIKit

// Протокол для передачи данных о событии
protocol WishEventCreationDelegate: AnyObject {
    func didCreateEvent(_ event: WishEventModel)
}

final class WishEventCreationView: UIViewController {
    
    // MARK: - Constants
    private enum Constants {
        static let stackViewSpacing: CGFloat = 16.0
        static let stackViewPadding: CGFloat = 20.0
    }
    
    // MARK: - UI Elements
    private let titleTextField = UITextField()
    private let descriptionTextField = UITextField()
    private let startDateTextField = UITextField()
    private let endDateTextField = UITextField()
    private let saveButton = UIButton(type: .system)
    
    weak var delegate: WishEventCreationDelegate? // Делегат для передачи события

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    // MARK: - Настройка пользовательского интерфейса
    private func setupUI() {
        titleTextField.placeholder = "Название желания"
        descriptionTextField.placeholder = "Описание желания"
        startDateTextField.placeholder = "Дата начала"
        endDateTextField.placeholder = "Дата окончания"
        
        let stackView = UIStackView(
            arrangedSubviews: [
                titleTextField,
                descriptionTextField,
                startDateTextField,
                endDateTextField,
                saveButton
            ]
        )
        stackView.axis = .vertical
        stackView.spacing = Constants.stackViewSpacing
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stackView)
        
        stackView.pinCenter(to: view)
        stackView.pinLeft(to: view, Constants.stackViewPadding)
        stackView.pinRight(to: view, Constants.stackViewPadding)
        
        saveButton.setTitle("Сохранить желание", for: .normal)
        saveButton.addTarget(self, action: #selector(saveEvent), for: .touchUpInside)
    }
    
    // MARK: - Действие сохранения события
    @objc private func saveEvent() {
        guard let title = titleTextField.text, !title.isEmpty else {
            showAlert(message: "Нельзя добавлять желания без названия😕")
            return
        }
        
        // Создаем новое событие
        let newEvent = WishEventModel(
            title: title,
            description: descriptionTextField.text ?? "",
            startDate: startDateTextField.text ?? "",
            endDate: endDateTextField.text ?? ""
        )
        
        delegate?.didCreateEvent(newEvent) // Передаем событие через делегат
        dismiss(animated: true, completion: nil) // Закрываем представление
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
