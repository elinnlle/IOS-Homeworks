//
//  AddWishCell.swift
//  edmatveenkoPW2
//
//  Created by Эльвира Матвеенко on 05.11.2024.
//

import UIKit

class AddWishCell: UITableViewCell {
    
    // MARK: - Properties
    static let reuseId = "AddWishCell"
    
    private enum Constants {
        static let textViewBorderColor: UIColor = .gray
        static let textViewBorderWidth: CGFloat = 1
        static let textViewCornerRadius: CGFloat = 5
        static let textViewFontSize: CGFloat = 16
        static let textViewHeight: CGFloat = 60
        static let addButtonCornerRadius: CGFloat = 5
        static let addButtonHeight: CGFloat = 44
        static let horizontalPadding: CGFloat = 16
        static let verticalPadding: CGFloat = 8
    }
    
    private let textView: UITextView = {
        let tv = UITextView()
        tv.layer.borderColor = Constants.textViewBorderColor.cgColor
        tv.layer.borderWidth = Constants.textViewBorderWidth
        tv.layer.cornerRadius = Constants.textViewCornerRadius
        tv.font = UIFont.systemFont(ofSize: Constants.textViewFontSize)
        return tv
    }()
    
    private let addButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Добавить желание", for: .normal)
        button.layer.cornerRadius = Constants.addButtonCornerRadius
        button.backgroundColor = .white
        button.setTitleColor(.black, for: .normal)
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.gray.cgColor
        return button
    }()
    
    var addWish: ((String) -> ())? // Опциональное замыкание для добавления желания
    
    // MARK: - Initializers
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        addButton.addTarget(self, action: #selector(addWishButtonTapped), for: .touchUpInside)
        
        self.backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup Views
    private func setupViews() {
        contentView.backgroundColor = .clear
        contentView.addSubview(textView)
        contentView.addSubview(addButton)
        
        textView.pinLeft(to: contentView, Constants.horizontalPadding)
        textView.pinRight(to: contentView, Constants.horizontalPadding)
        textView.pinTop(to: contentView, Constants.verticalPadding)
        textView.setHeight(mode: .equal, Constants.textViewHeight)
        
        addButton.pinLeft(to: textView)
        addButton.pinRight(to: textView)
        addButton.pinTop(to: textView.bottomAnchor, Constants.verticalPadding)
        addButton.setHeight(mode: .equal, Constants.addButtonHeight)
        addButton.pinBottom(to: contentView, Constants.verticalPadding)
    }
    
    // MARK: - Actions
    @objc private func addWishButtonTapped() {
        guard let wishText = textView.text, !wishText.isEmpty else { return }
        addWish?(wishText) // Вызов замыкания с текстом желания
        textView.text = "" // Очистка текстового поля после добавления
    }
}
